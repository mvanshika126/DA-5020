                                     # DA5020 – Assignment 1 




#Question 1 Compare and contrast the terms below: 

#i. What is the difference between an R script and a knitted R document
#(i.e. the difference between a .R file and a .RMD file).
#ANSWER:
#The major difference between them is .Rmd files are used for Documentation
#and for writing codes and normal R file is just used for running normal R codes.

#ii.What is the difference between continuous variables and categorical variables?
#ANSWER:
#Continuous variables are numeric/datetime values that can have infinite values,
#for example height,weight,age,time temperature of a person was taken or the time 
#an amazon package was delivered.
#Categorical variables contain a finite number of categories or distinct groups
#like skin color can be light,
#lgiht,fair,medium, melanated .It is not necessary that they appear in a logical order.






#Question 2 — Explain the purpose of the R functions below and provide examples to
#support your explanation:
#i.When should you use: dim(), head(), tail() and view().
#ANSWER:
dim(msleep)#function used to get the dimensions of the dataframe,matrix or array,
#for example, msleep has 83 rows and 11 columns.
head(msleep)#function used to obtain first 6 rows of a dataframe or matrix by default,
#can be changed with n=(to the no.of obs one would like to display).
tail(msleep)#function to obtain the last 6 rows of a dataframe or matrix by default,
#the number can be changed using n=(the no. of observations one would like to disply).
View(msleep)#function to obtain a spreadsheet like view for the  entire data frame in another tab .


#ii. Read ?facet_wrap and state how it is used when visualizing data, and what is
#the purpose of nrow and ncol. 
#ANSWER:
?facet_wrap
#facet_wrap() function is particularly useful for categorical variables to
#create matrix of panels plot for better use of screen and clearer display
#it basically creates subplots and each panel displays a subset of the data ,
#the function is specifically used for when there is one variable to display with many levels.
#ncol is used to define the number of columns the graphs will be distributed in.
#nrow is used to define the number of rows that the graphs will be distributed in.
#we are plotting the bodywt as a function of brainwt for  each conservation status type.
names(msleep)
v <- ggplot(msleep, aes(bodywt, brainwt)) + geom_point()
v + facet_wrap(vars(conservation))



#iii.When should you use str() versus summary()? 
#ANSWER:
str(msleep)
#str() function tells us  the number of rows (observations) and columns (variables). It tells 
#us the column names,the class of each column (what kind of data is stored in it),and the first few 
#observations of each variable.

summary(msleep)
#summary() function tells us the descriptive statistics of the dataset like the mean, mode ,
#median, max value etc for each variable in the dataset.






#Question3
#Use the msleep dataset, which is available in the ggplot package, to answer the following questions. 
#loading important packages 
library(ggplot2)
#to check the description of the dataset and look at the variables 
help(msleep)

#ANSWER:
#i. How many rows and columns are in the dataset?
#ANSWER:
dim( msleep)
#using dim() to get the number of columns and rows ,there are 11 columns and 83 rows


#ii. Use the head function to display the first 2 rows of the dataset and use the tail 
#function to display the last 5 rows.
#ANSWER:
head( msleep, n=2)
tail( msleep,n=5)

#iii.Display the column names of the categorical variables and the continuous variables. 
#ANSWER:
#using help(msleep) to see the categorical and continuous variables
help(msleep)
#select columns that are categorical 
names(msleep[,1:5])
#select continuous variables
names(msleep[,6:11])
#we could use name(msleep) to display all names at the same time.
names(msleep)


#iv.Does the following code snippet below display a visualization? If so,
#explain the chart that was displayed; and if not explain the reason that the chart was not displayed.
#ANSWER:
ggplot(data=msleep)
#here the variables to be plotted on x and y axis aren't defined and hence,
#just the code itself cannot plot the graph,also here it is not defined the kind of plot that's 
#required ,that is either a scatter,barplot,boxplot etc
ggplot(data, aes(x = conservation, y = awake)) #here even if we define the x and y
#variables but if we skip the type of graph we need then  we get a graph but no values plotted.
ggplot(data, aes(x = conservation, y = awake)) + geom_point()# defining x and y 
#variables and also the kind of plot ,that is, a scatterplot will result in a graph with values plotted.


#v. Use the head() function to display the first 20 rows and state a possible reason 
#that there are NA in the dataset. (i.e. what does this mean/imply when the data contains NA values)?
#ANSWER:
head(msleep,n=20)
#NA is to represent missing values that could be character or numeric ,
#any function performed on an array or columns with missing values will give the result as
#NA.Also if character column type has numeric value or  vice versa will also be a case of a value=NA.


#vi.Create a scatterplot showing the relationship between sleep_total and bodywt. 
#What does the scatterplot tell you about this relationship? 
#ANSWER:
ggplot(msleep, aes(x = sleep_total, y = bodywt)) +geom_point()
#the relationship is a little hard to tell at first glance as the points are very much
#populated in one place due to the large scale of the bodywt variable on y-axis.
# the variation in bodywt w.r.t sleep_total is less than  1 kg.
#also there are two outliers in this graph


#vii. Create a scatterplot showing the relationship between sleep_total and bodywt.
#Also,rescale the y axis using a log scale. Hint: use scale_y_log10.
#Does rescaling the axis help you to interpret the data easier? Explain your answer
#ANSWER:
ggplot(data, aes(x = sleep_total, y = bodywt)) + geom_point() + scale_y_log10()
#the sleep-total is plotted as a function of bodywt,the variation  can be seen but with a more zoomed view .
#as we have used log scale the graph is definitely easier to make sense of in one glance.
#most of the variation in the bodywt is less than  1 kg.
#the 2 outliers have been skipped due to the use of scale_y_log10() 

#viii.(5 pts) Create a scatterplot showing the relationship between sleep_total and bodywt.
#Also, rescale the y axis using a log scale and apply facet_wrap using the vore column .
#What does the scatterplot indicate about the relationship between sleep_total and bodywt in herbivores?
#ANSWER:
g<-ggplot(data, aes(x = sleep_total, y = bodywt)) + geom_point() + scale_y_log10()
g<-g+ facet_wrap(vars(vore))
g + facet_wrap(vars(vore))
#the relationship for herbivores is that of a negative type as bodywt is decreasing with
#increasing sleep_total(negative correlation).

#ix.(10 pts) Create a bar chart of the dataset grouped by vore Hint: use geom_bar(). 
#ANSWER:
ggplot(msleep, aes(x = vore)) +geom_bar()






